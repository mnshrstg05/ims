// config/cloudinaryConfig.js
const cloudinary = require('cloudinary').v2;

cloudinary.config({
  cloud_name: "di1o13yuj",
  api_key: "444755977312791",
  api_secret: "jR6n2vu-z2t9qGZ8VHdxNa0iQ5o",
});

module.exports = cloudinary;

const dbConfig = {
    dbURL: "mongodb+srv://dmntst07:HivxdVz9AofMKm8h@cluster0.h4zeekr.mongodb.net/PfixsIDV?retryWrites=true&w=majority&appName=Cluster0",
};

module.exports = dbConfig;
//mongodb+srv://atlas-sample-dataset-load-67fa47d93e06be489d811e1e:<db_password>@cluster0.h4zeekr.mongodb.net/myDatabaseName?retryWrites=true&w=majority&appName=Cluster0
